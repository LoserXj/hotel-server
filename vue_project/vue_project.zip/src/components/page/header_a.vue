<!--<template>-->

<!--  <header id="header" class="container-fluid p-0">-->
<!--&lt;!&ndash;    <el-row :gutter="20">&ndash;&gt;-->
<!--&lt;!&ndash;      <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>&ndash;&gt;-->
<!--&lt;!&ndash;      <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>&ndash;&gt;-->
<!--&lt;!&ndash;      <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>&ndash;&gt;-->
<!--&lt;!&ndash;      <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>&ndash;&gt;-->
<!--&lt;!&ndash;    </el-row>&ndash;&gt;-->

<!--    <div class="header">-->
<!--      <img class="avatar" src="../../assets/images/logo.png" alt="头像"/>-->
<!--      <section class="banxin">-->
<!--        <div class="left">欢迎来到sustech酒店</div>-->
<!--        <div class="right">-->
<!--          <ul class="ul">-->
<!--            <li class="avatar_li" @click="userClickFn">-->
<!--              <img class="avatar" src="../../assets/images/logo.png" alt="头像"/>-->
<!--              用户名：{{ userInfo.nickName }}-->
<!--            </li>-->
<!--            <li @click="userClickFn">我的积分：{{ userInfo.coin }}</li>-->
<!--            <li @click="getCoinClickFn">积分商城</li>-->
<!--            <li @click="getCoinClickFn">我的订单</li>-->
<!--          </ul>-->
<!--        </div>-->
<!--      </section>-->
<!--    </div>-->
<!--  </header>-->
<!--</template>-->

<!--<script>-->
<!--// import { getUserInfoApi} from '../request/api'-->
<!--export default {-->
<!--  name: `header_a`,-->
<!--  data() {-->
<!--    return {-->
<!--      userInfo: {-->
<!--        // headImg: require('../assets/images/userImg.png'),-->
<!--        nickName: '左不凡',-->
<!--        coin: '&#45;&#45;',-->
<!--        // cartNum: 0-->
<!--      }-->
<!--    }-->
<!--  },-->
<!--  // created() {-->
<!--  //   let mycode = this.$route.query.code-->
<!--  //   if (mycode) { //有code代表了刚刚扫码登录-->
<!--  //     // 有code才去置换token-->
<!--  //     WeixinLoginApi({-->
<!--  //       code: mycode-->
<!--  //     }).then(res => {-->
<!--  //       if (res.code===0) {-->
<!--  //         // 登录成功存储token-->
<!--  //         localStorage.setItem('x-auth-token',res['x-auth-token'])-->
<!--  //         // vuex中切换登录的状态（Header组件的登录改为购物车）-->
<!--  //         this.$store.commit('changeIsLogined')-->
<!--  //         // 提示用户-->
<!--  //         this.$store.dispatch('changeToastAsync',{msg:'登录成功',type: 'success'})-->
<!--  //         // 获取用户信息-->
<!--  //         this.getUserInfo()-->
<!--  //         // 清除地址栏上的code-->
<!--  //         this.$router.replace(this.$route.path)-->
<!--  //         //这里是否还用刷新当前页？（应该是不用了）-->
<!--  //       } else {-->
<!--  //         // 登录失败-->
<!--  //         if (res.code===407) {-->
<!--  //           let myuuid = res.uuid-->
<!--  //           localStorage.setItem('uuid',myuuid)-->
<!--  //           this.$store.commit('showBingding')-->
<!--  //         } else {-->
<!--  //           if (res.code===400) {-->
<!--  //             this.$store.dispatch('changeToastAsync',{msg:'请用微信重新扫码登录',type: 'erro'})-->
<!--  //           }-->
<!--  //         }-->
<!--  //       }-->
<!--  //     })-->
<!--  //   } else {-->
<!--  //     // 这里代表没有code，但是并不确定用户是否登录了，所以在这重新判断一下token，进行header组件中登录和购物车的切换-->
<!--  //     let mytoken = localStorage.getItem('x-auth-token')-->
<!--  //     if (mytoken) {-->
<!--  //       // 这里代表用户已经登录，不管是微信或者手机登录的-->
<!--  //       // 所以在这儿发起获取用户信息的请求-->
<!--  //       let myuserInfo = localStorage.getItem('userInfo')-->
<!--  //       if (myuserInfo) {-->
<!--  //         // 如果已经有用户的信息就用localStorage中的的数据，不在发起请求-->
<!--  //         let userInfo = JSON.parse(localStorage.getItem('userInfo'))-->
<!--  //         this.userInfo = userInfo-->
<!--  //       } else {-->
<!--  //         this.getUserInfo()-->
<!--  //       }-->
<!--  //     }-->
<!--  //   }-->
<!--  // },-->
<!--  methods: {-->
<!--    // 获取用户信息-->
<!--    getUserInfo() {-->
<!--      // getUserInfoApi().then(res => {-->
<!--      //   if (res.code===0) {-->
<!--      //     let userInfos = res.data.userInfo-->
<!--      //     let cartnum = res.data.cartTotal-->
<!--      //     let userInfo = {-->
<!--      //       headImg: userInfos.headImg,-->
<!--      //       nickName: userInfos.nickName,-->
<!--      //       coin: userInfos.coin,-->
<!--      //       cartNum: cartnum-->
<!--      //     }-->
<!--      //     this.userInfo = userInfo-->
<!--      //     localStorage.setItem('userInfo',JSON.stringify(userInfo))-->
<!--      //   }-->
<!--      // })-->
<!--    },-->
<!--    // 打开登录模态框-->
<!--    openLogin() {-->
<!--      this.$store.commit('showModalFn')-->
<!--    },-->
<!--    // 用户名和我的积分的点击事件-->
<!--    userClickFn() {-->
<!--      let mytoken = localStorage.getItem('x-auth-token')-->
<!--      if (!mytoken) {-->
<!--        this.$store.dispatch('changeToastAsync', {msg: '请先登录', type: 'wran'})-->
<!--        return-->
<!--      }-->
<!--      this.$router.push('/user/personal')-->
<!--    },-->
<!--    // 获取积分的点击事件-->
<!--    getCoinClickFn() {-->
<!--      let mytoken = localStorage.getItem('x-auth-token')-->
<!--      if (mytoken) {-->
<!--        this.$store.dispatch('changeToastAsync', {msg: '此功能暂未开放', type: 'erro'})-->
<!--        return-->
<!--      }-->
<!--      this.$store.dispatch('changeToastAsync', {msg: '请先登录', type: 'wran'})-->
<!--    },-->
<!--    // 跳转到购物车页面-->

<!--  },-->
<!--  // 监测路由然后重新加载header组件，不然用户退出后，跳转到其他页面后，header组件中显示的还是用户已经登录的状态-->
<!--  watch: {-->
<!--    $route(to, from) {-->
<!--      if (from.path.substring(0, 5) === '/user') {-->
<!--        // 通知app组件重新加载header组件-->
<!--        this.$emit('gengxinnum')-->
<!--      }-->
<!--      return-->
<!--      // this.$router.go(0); // 刷新页面-->
<!--    }-->
<!--  }-->
<!--};-->
<!--</script>-->

<!--<style>-->

<!--.header {-->
<!--  width: 100%;-->
<!--  height: 40px;-->
<!--  background: #17b9b9;-->
<!--  color: #FFFEFE;-->
<!--  font-size: 14px;-->
<!--  display: flex;-->
<!--  justify-content: space-between;-->
<!--  align-items: center;-->
<!--}-->

<!--.right {-->
<!--  display: flex;-->
<!--  align-items: center;-->
<!--  cursor: pointer;-->
<!--  margin-right: 20px;-->
<!--}-->

<!--.left {-->

<!--}-->

<!--ul {-->
<!--  list-style: none;-->
<!--  display: flex;-->
<!--  align-items: center;-->
<!--}-->


<!--.avatar_li {-->
<!--  display: flex;-->
<!--  align-items: center;-->
<!--}-->


<!--.avatar {-->
<!--  width: 26px;-->
<!--  margin-right: 5px;-->
<!--  border-radius: 50%;-->
<!--}-->


<!--.btn {-->
<!--  cursor: pointer;-->
<!--  width: 124px;-->
<!--  text-align: center;-->
<!--  height: 40px;-->
<!--  line-height: 40px;-->
<!--  background: blue;-->
<!--}-->

<!--.cart_btn {-->
<!--  cursor: pointer;-->
<!--  width: 124px;-->
<!--  height: 40px;-->
<!--  background: blue;-->
<!--  display: flex;-->
<!--  justify-content: center;-->
<!--  align-items: center;-->
<!--}-->

<!--span {-->
<!--  margin: 0 6px 0 8px;-->
<!--}-->

<!--b {-->
<!--  width: 22px;-->
<!--  height: 22px;-->
<!--  line-height: 22px;-->
<!--  text-align: center;-->
<!--  background: #fd604d;-->
<!--  border-radius: 11px;-->
<!--}-->

<!--.el-row {-->
<!--  margin-bottom: 20px;-->
<!--&:last-child {-->
<!--   margin-bottom: 0;-->
<!-- }-->
<!--}-->
<!--.el-col {-->
<!--  border-radius: 4px;-->
<!--}-->
<!--.bg-purple-dark {-->
<!--  background: #99a9bf;-->
<!--}-->
<!--.bg-purple {-->
<!--  background: #d3dce6;-->
<!--}-->
<!--.bg-purple-light {-->
<!--  background: #e5e9f2;-->
<!--}-->
<!--.grid-content {-->
<!--  border-radius: 4px;-->
<!--  min-height: 36px;-->
<!--}-->
<!--.row-bg {-->
<!--  padding: 10px 0;-->
<!--  background-color: #f9fafc;-->
<!--}-->

<!--</style>-->
<template>
  <div class="header">
<!--    <img class="avatar" src="../../assets/images/logo.png" alt="头像"/>-->
    <el-menu
        :default-active="activeIndex2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b">
      <el-menu-item index="1">
        用户名
      </el-menu-item>
      <el-sub-menu index="2">
        <template v-slot:title>个人信息</template>
        <el-menu-item index="2-1">全部订单</el-menu-item>
        <el-menu-item index="2-2">用户中心</el-menu-item>
        <el-menu-item index="2-3">更多</el-menu-item>
        <el-sub-menu index="2-4">
          <template v-slot:title>选项4</template>
          <el-menu-item index="2-4-1">选项1</el-menu-item>
          <el-menu-item index="2-4-2">选项2</el-menu-item>
          <el-menu-item index="2-4-3">选项3</el-menu-item>
        </el-sub-menu>
      </el-sub-menu>
      <el-menu-item index="3" >订单管理</el-menu-item>

      <el-menu-item index="4">积分商城</el-menu-item>
      <el-menu-item index="5">客服</el-menu-item>
    </el-menu>
  </div>

</template>
<script>
export default {
  data() {
    return {
      activeIndex: '1',
      activeIndex2: '1'
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    }
  }
}
</script>
<style>


ul {
    list-style: none;
     display: flex;
     align-items: center;
  }


.header {
  width: 100%;
  height: 59px;
  /*background: #17b9b9;*/
  color: #FFFEFE;
  font-size: 14px;
  /*display: table;*/
  justify-content: space-between;
  align-items: center;
}

.avatar {
  width: 26px;
  margin-right: 5px;
  border-radius: 50%;
}
</style>
