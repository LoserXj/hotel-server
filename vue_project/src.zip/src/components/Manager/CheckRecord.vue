<template>
  <body>
  <div class="content">
    <router-view></router-view>
  </div>
  <el-container class="layout-container-demo" style="height: 100%">

    <el-aside>
      <el-scrollbar>
        <div class="side">
          <el-menu
              active-text-color="#ffd04b"
              background-color="#545c64"
              text-color="#fff"
              router="router"
              style="height: 100vh;position: -webkit-sticky;position: sticky;top: 0;"
          >

            <el-menu-item route="/ManagerSystem" index="1">
              <el-icon><UserFilled /></el-icon>
              <span class="functions">管理员主页</span>
            </el-menu-item>
            <el-menu-item route="/CheckRecord" index="2">
              <el-icon><Menu /></el-icon>
              <span class="functions">订房记录</span>
            </el-menu-item>
            <el-menu-item route="/ModifyRoom" index="3">
              <el-icon><Document /></el-icon>
              <span class="functions">房间信息</span>
            </el-menu-item>
            <el-sub-menu index="4">
              <template #title>
                <el-icon><DataAnalysis /></el-icon>酒店数据
              </template>
              <el-menu-item-group>
                <template #title>查看数据</template>
                <el-sub-menu index="4-1">
                  <template #title>统计房间订购量</template>
                  <el-menu-item index="4-1-1">按天查看</el-menu-item>
                  <el-menu-item index="4-1-2">按房型查看</el-menu-item>
                </el-sub-menu>
                <el-menu-item index="4-2">营业额</el-menu-item>
              </el-menu-item-group>
            </el-sub-menu>
          </el-menu>
        </div>

      </el-scrollbar>
    </el-aside>


    <el-container>
      <el-header style="text-align: right; ">
        <div class="title">
          <span>{{this.title}}</span>
        </div>
        <div class="toolbar">
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Message/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px" >邮件</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><ChatLineSquare/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">信息</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Setting/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">设置</span>
        </div>
      </el-header>

      <el-main>
        <el-scrollbar>
          <el-card class="box-card" shadow="always" >
            <div style="">

              <h2>
                查询订房记录
              </h2>
            </div>

            <div class="search">
              <el-icon><Edit /></el-icon>
              <span>顾客姓名</span>

              <el-input
                  v-model="GuestName"
                  class="w-50 m-2"
                  placeholder="Type something"
                  clearable
                  style="width: 20%; margin-right: 20%"

              ></el-input>

              <el-icon><Edit /></el-icon>
              <span>手机号&#12288;</span>

              <el-input
                  v-model="GuestTelephoneNum"
                  class="w-50 m-2"
                  placeholder="Type something"
                  clearable
                  style="width: 20%"
              ></el-input>

            </div>

            <div class="search">

            </div>

            <!--      <div class="search">-->
            <!--        <el-icon><HomeFilled /></el-icon>-->
            <!--        <span class="demonstration">酒店城市</span>-->
            <!--        <el-select v-model="locationValue" filterable placeholder="请选择">-->
            <!--          <el-option-->
            <!--              v-for="item in locationOptions"-->
            <!--              :key="item.value"-->
            <!--              :label="item.label"-->
            <!--              :value="item.value">-->
            <!--          </el-option>-->
            <!--        </el-select>-->
            <!--        <br>-->
            <!--      </div>-->

            <div class="search">

              <el-icon><Edit /></el-icon>
              <span>房间号&#12288;</span>

              <el-input
                  v-model="RoomNum"
                  class="w-50 m-2"
                  placeholder="Type something"
                  clearable
                  style="width: 20%; margin-right: 20%"
              ></el-input>

              <el-icon><Operation/></el-icon>
              <span class="demonstration">订单状态</span>
              <el-select v-model="StateValue" filterable placeholder="请选择">
                <el-option
                    v-for="item in State"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                </el-option>
              </el-select>


            </div>
            <div class="search">
              <el-icon><Calendar /></el-icon>
              <span class="demonstration">入住时间</span>
              <el-date-picker
                  v-model="inDate"
                  type="date"
                  placeholder="开始日期"
                  style="width: 20%"
              >
              </el-date-picker>
              <span>&#12288;至&#12288;</span>
              <el-date-picker
                  v-model="outDate"
                  type="date"
                  placeholder="结束日期"
                  style="width: 20%; margin-right: 5%"
              >
              </el-date-picker>

              <el-button type="primary" size="large" :icon="Search" round @click="onSubmit">Search</el-button>
              <el-button type="danger" size="large" :icon="Delete" round @click="clear">Clear</el-button>

            </div>
            <div class="search">

            </div>



            <div>

            </div>

          </el-card>
          <el-card>
            <el-table :data="tableData"  style="width: 100%">
              <el-table-column prop="GuestName" label="顾客姓名" width="180" />
              <el-table-column prop="GuestTelephoneNum" label="手机号" width="180" />
              <el-table-column prop="inDate" label="入住日期" width="180" />
              <el-table-column prop="outDate" label="结束日期" width="180" />
              <el-table-column prop="RoomID" label="房间号" />
            </el-table>
          </el-card>
        </el-scrollbar>
      </el-main>
    </el-container>

  </el-container>


  </body>

</template>

<script>

import {
  Search,
  Delete,
  Edit,
  Calendar,
  Operation,
  UserFilled,
  DataAnalysis,
  Menu,
  Document, Message, Setting, ChatLineSquare
} from '@element-plus/icons-vue'
export default {
  name: "CheckRecord",

  components:{
    // HomeFilled,
    Edit,
    Calendar,
    Operation,
    UserFilled,
    DataAnalysis,
    Menu,
    Document,
    Message,
    Setting,
    ChatLineSquare,
  },

  data() {
    return {
      title:'订房记录',

      RoomNum:'',
      inDate:'',
      outDate:'',
      GuestName:'',
      GuestTelephoneNum:'',

      Search: Search,
      Delete: Delete,


      // teenNum: 1,
      //城市
      locationOptions: [{
        value: '选项1',
        label: '深圳'
      }, {
        value: '选项2',
        label: '广州'
      }, {
        value: '选项3',
        label: '抚州'
      }, {
        value: '选项4',
        label: '南昌'
      }, {
        value: '选项5',
        label: '北京'
      }],
      locationValue: '',

      State:[{
        value: '选项1',
        label: '已预定'
      }, {
        value: '选项2',
        label: '已支付'
      }, {
        value: '选项2',
        label: '已评价'
      }],
      StateValue: '',


      tableData: [
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
        {
          GuestName: 'Tom',
          GuestTelephoneNum: 'sdf',
          inDate: '2016-05-03',
          outDate: '342324',
          RoomID: '414342',
        },
      ]



    };
  },
  methods: {
    handleChange(value) {
      console.log(value);
    },

    clear() {
      this.RoomNum=''
      this.inDate=''
      this.outDate=''
      this.GuestName=''
      this.GuestTelephoneNum=''
      this.StateValue=''
    },

    onSubmit() {
      this.$http.get('http://localhost:8081/user/login', {params:{tel: this.username, password: this.password}})
          .then(res => {
            if (res.data.code === 200)

              this.$router.push('/main');
            else if (res.data.status === 200 && res.data.msg === 'manager')
              this.$router.push('/manager');
            else {
              this.$message.error(res.data.msg);
            }
          })
    },


  }
}
</script>

<style scoped>

.layout-container-demo .el-header {
  position: relative;
  background-image: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);
  color: var(--el-text-color-primary);
}
.layout-container-demo .el-aside {
  color: var(--el-text-color-primary);
  background: white;
  width: 20%;
  height: 100vh;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
.layout-container-demo .el-menu {
  border-right: none;
  height: 100vh;


}
.layout-container-demo .el-main {
  padding: 2%;
  background-image: url("../../assets/manager/img_4.png");
  background-repeat:no-repeat ;
  background-size:100% 100%;
  background-attachment: fixed;
}
.layout-container-demo .toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  right: 20px;
  font-size:16px
}

.layout-container-demo .title {
  float: left;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.functions:hover{
  color: #ffd04b;
}


.box-card{
  background-size: cover;
  background-image: linear-gradient(to top, #f3e7e9 0%, #e3eeff 99%, #e3eeff 100%);
}

.search{
  margin-bottom: 10px;
}

h2{
  font-size: 25px;
  color: white;
  text-shadow:0px 1px 0px #c0c0c0,
  0px 2px 0px #b0b0b0,
  0px 3px 0px #a0a0a0,
  0px 4px 0px #909090,
  0px 5px 10px rgba(0, 0, 0, .9);
}

</style>
