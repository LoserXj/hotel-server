<template>
  <body>
  <div class="content">
    <router-view></router-view>
  </div>
  <el-container class="layout-container-demo" style="height: 100%">

    <el-aside>
      <el-scrollbar>
        <div class="side">
          <el-menu
              active-text-color="#ffd04b"
              background-color="#545c64"
              text-color="#fff"
              router="router"
              style=""
          >

            <el-menu-item route="/ManagerSystem" index="1">
              <el-icon><UserFilled /></el-icon>
              <span class="functions">管理员主页</span>
            </el-menu-item>
            <el-menu-item route="/CheckRecord" index="2">
              <el-icon><Menu /></el-icon>
              <span class="functions">订房记录</span>
            </el-menu-item>
            <el-menu-item route="/ModifyRoom" index="3">
              <el-icon><Document /></el-icon>
              <span class="functions">房间信息</span>
            </el-menu-item>
            <el-sub-menu index="4">
              <template #title>
                <el-icon><DataAnalysis /></el-icon>酒店数据
              </template>
              <el-menu-item-group>
                <template #title>查看数据</template>
                <el-sub-menu index="4-1">
                  <template #title>统计房间订购量</template>
                  <el-menu-item index="4-1-1">按天查看</el-menu-item>
                  <el-menu-item index="4-1-2">按房型查看</el-menu-item>
                </el-sub-menu>
                <el-menu-item index="4-2">营业额</el-menu-item>
              </el-menu-item-group>
            </el-sub-menu>
          </el-menu>
        </div>

      </el-scrollbar>
    </el-aside>


    <el-container>
      <el-header style="text-align: right">
        <div class="title">
          <span>{{this.title}}</span>
        </div>
        <div class="toolbar">
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Message/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px" >邮件</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><ChatLineSquare/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">信息</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Setting/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">设置</span>
        </div>
      </el-header>

      <el-main>
        <el-scrollbar>
          <el-card>
            <el-table :data="tableData" style="height: 100%; width: 100%">
              <el-table-column prop="price" label="价格" />
              <el-table-column prop="type" label="类型名称"  />
              <el-table-column prop="hotel" label="酒店" />
              <el-table-column prop="message" label="信息" />
              <el-table-column prop="picture" label="房间图片" />
              <el-table-column prop="bedNum" label="床" />
              <el-table-column prop="hasBreakfast" label="早餐" />
              <el-table-column label="Operations">
                <template #default="scope">
                  <el-button class="btn" size="small" @click="handleEdit(scope.$index)">Edit</el-button>
                  <el-button class="btn" size="small" type="danger" @click="handleDelete(scope.$index)">Delete</el-button>
                </template >
              </el-table-column>
            </el-table>
          </el-card>


          <el-dialog v-model="dialogFormVisible.show" title="编辑房间信息" ><el-form :model="form">
            <el-form-item label="价格" >
              <el-input v-model="form.price" autocomplete="off" />
            </el-form-item>
            <el-form-item label="类型名称">
              <el-input v-model="form.type" autocomplete="off" />
            </el-form-item>
            <el-form-item label="酒店">
              <el-input v-model="form.hotel" autocomplete="off" />
            </el-form-item>
            <el-form-item label="信息">
              <el-input v-model="form.message" autocomplete="off" />
            </el-form-item>
            <el-form-item label="房间图片">
              <el-input v-model="form.picture" autocomplete="off" />
            </el-form-item>
            <el-form-item label="床">
              <el-input-number v-model="form.bedNum" :min="1" :max="10" @change="handleChange" />
            </el-form-item>
            <el-form-item label="早餐" >
              <el-select v-model="form.hasBreakfast" placeholder="">
                <el-option label="有早餐" value="有早餐" />
                <el-option label="无早餐" value="无早餐" />
              </el-select>
            </el-form-item>
          </el-form>
            <template #footer>
      <span class="dialog-footer">

        <el-button type="primary" @click=submit()>
          Confirm
        </el-button>

        <el-button @click="dialogFormVisible.show = false">Cancel</el-button>
      </span>
            </template>
          </el-dialog>
        </el-scrollbar>
      </el-main>
    </el-container>

  </el-container>


  </body>


</template>


<script>

import { reactive } from 'vue'

import {ChatLineSquare, Edit, Message, Setting} from '@element-plus/icons-vue'
import { UserFilled, DataAnalysis, Menu, Document  } from '@element-plus/icons-vue'

export default {

  name: 'ModifyRoom',
  components: {
    UserFilled,
    DataAnalysis,
    Menu,
    Document,
    Message,
    Setting,
    ChatLineSquare,
  },

  data() {

    return {
      title:'房间信息',

      dialogFormVisible: {
        show: false,
        index: 1,
      },

      form:reactive({
        price:'',
        type:'',
        hotel:'',
        message:'',
        picture: '',
        bedNum: '',
        hasBreakfast: '',
      }) ,

      Edit: Edit,

      bedOptions: [{
        value: '选项1',
        label: '大床'
      }, {
        value: '选项2',
        label: '双床'
      }, {
        value: '选项3',
        label: '单人床'
      }],
      bedValue: '',

      breakfastOptions: [{
        value: '选项1',
        label: '有早餐'
      }, {
        value: '选项2',
        label: '无早餐'
      }],
      breakfastValue: '',


      tableData: [
        {
          price:1.0,
          type:'2',
          hotel:'1',
          message:'1',
          picture: '2016-05-03',
          bedNum: 43,
          hasBreakfast: 'No. 189, Grove St, Los Angeles',
        },
        {
          price:1.0,
          type:'3',
          hotel:'1',
          message:'1',
          picture: '2016-05-03',
          bedNum: 43,
          hasBreakfast: 'No. 189, Grove St, Los Angeles',
        },{
          price:1.0,
          type:'4',
          hotel:'1',
          message:'1',
          picture: '2016-05-03',
          bedNum: 43,
          hasBreakfast: 'No. 189, Grove St, Los Angeles',
        },{
          price:1.0,
          type:'5',
          hotel:'1',
          message:'1',
          picture: '2016-05-03',
          bedNum: 43,
          hasBreakfast: 'No. 189, Grove St, Los Angeles',
        },
      ]

    };
  },


  methods: {
    handleChange(value) {
      console.log(value);
    },

    handleEdit(index){
      this.dialogFormVisible.show = true
      this.dialogFormVisible.index = index
    },

    handleDelete(index){
      this.tableData.splice(index,1)
    },

    submit(){
      this.tableData[this.dialogFormVisible.index] = this.form
      this.dialogFormVisible.show = false
    },

    onSubmit(){
      //使用axios发送请求到后端
      this.$http.get('http://localhost:8081/user/login', {params:{tel: this.username, password: this.password}})
          .then(res => {
            if (res.data.code === 200)

              this.$router.push('/main');
            else if (res.data.status === 200 && res.data.msg === 'manager')
              this.$router.push('/manager');
            else {
              this.$message.error(res.data.msg);
            }
          })
    },
  }
};
</script>

<style scoped>

.layout-container-demo .el-header {
  position: relative;
  background-image: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);
  color: var(--el-text-color-primary);
}
.layout-container-demo .el-aside {
  color: var(--el-text-color-primary);
  background: white;
  width: 20%;
  height: 100vh;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
.layout-container-demo .el-menu {
  border-right: none;
  height: 100vh;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
.layout-container-demo .el-main {
  padding: 2%;
  background-image: url("../../assets/manager/img_5.png");
  background-repeat:no-repeat ;
  background-size:100% 100%;
  background-attachment: fixed;
}
.layout-container-demo .toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  right: 20px;
  font-size:16px
}

.layout-container-demo .title {
  float: left;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;

}

.functions:hover{
  color: #ffd04b;
}


  .btn{
    margin-left: 0;
  }



  .el-button--text {
    margin-right: 15px;
  }
  .el-select {
    width: 300px;
  }
  .el-input {
    width: 300px;
  }
  .dialog-footer button:first-child {
    margin-right: 10px;
  }


</style>

