<template>

  <body>
  <div class="content">
    <router-view></router-view>
  </div>
  <el-container class="layout-container-demo" style="height: 100%">

    <el-aside>
      <el-scrollbar>
        <div class="side">
          <el-menu
              active-text-color="#ffd04b"
              background-color="#545c64"
              text-color="#fff"
              router="router"
          >
            
            <el-menu-item route="/ManagerSystem" index="1">
              <el-icon><UserFilled /></el-icon>
              <span class="functions">管理员主页</span>
            </el-menu-item>
            <el-menu-item route="/CheckRecord" index="2">
              <el-icon><Menu /></el-icon>
              <span class="functions">订房记录</span>
            </el-menu-item>
            <el-menu-item route="/ModifyRoom" index="3">
              <el-icon><Document /></el-icon>
              <span class="functions">房间信息</span>
            </el-menu-item>
            <el-sub-menu index="4">
              <template #title>
                <el-icon><DataAnalysis /></el-icon>
                <span class="functions">酒店数据</span>
              </template>
              <el-menu-item-group>
                <template #title>查看数据</template>
                <el-sub-menu index="4-1">
                  <template #title>
                    <span class="functions">统计房间订购量</span>
                  </template>
                  <el-menu-item index="4-1-1">
                    <span class="functions">按天查看</span>
                  </el-menu-item>
                  <el-menu-item index="4-1-2">
                    <span class="functions">按房型查看</span>
                  </el-menu-item>

                </el-sub-menu>
                <el-menu-item index="4-2">
                  <span class="functions">房间信息</span>
                </el-menu-item>
              </el-menu-item-group>
            </el-sub-menu>
          </el-menu>
        </div>

      </el-scrollbar>
    </el-aside>


    <el-container>
      <el-header style="text-align: right">

        <div class="title">
          <span>{{this.title}}</span>
        </div>

        <div class="toolbar">
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Message/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px" >邮件</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><ChatLineSquare/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">信息</span>
          <el-icon size="16px" style="margin-right: 1px; margin-top: 1px"><Setting/></el-icon>
          <span style="margin-right: 8px; margin-top: 1px">设置</span>
        </div>
      </el-header>

      <el-main>
        <el-scrollbar>
<!--          <el-row class="home" :gutter="20">-->
            <!--span默认一共是24，这里占8 下面占16，所以这两个分隔栏所占的宽度 是1:2-->
<!--            <el-col :span="8" style="margin-top: 20px; margin-left: auto; margin-right: auto">-->
              <!--shadow属性设置卡片阴影出现的时机-->
                <div style="margin-top:10%; text-align: center; vertical-align: middle">
                  <el-avatar :size="50" :src="userImg" />
                  <p>管理员</p>
                  <p>姓名：<span>哈哈哈</span></p>
                  <p>工号：<span>哈哈哈</span></p>
                  <p>手机：<span>121003</span></p>
                </div>

<!--            </el-col>-->
<!--            <el-col :span="16" style="margin-top: 20px">-->
<!--              -->
<!--            </el-col>-->
<!--          </el-row>-->
        </el-scrollbar>
      </el-main>
    </el-container>

  </el-container>

  </body>

</template>

<script>

import { UserFilled, DataAnalysis, Menu, Document, Message, Setting, ChatLineSquare} from '@element-plus/icons-vue'

export default {
  name: 'ManagerSystem',

  components: {
    UserFilled,
    DataAnalysis,
    Menu,
    Document,
    Message,
    Setting,
    ChatLineSquare,
  },
  data() {
    return {
      title:'管理员主页',

      //TODO: 图片
      userImg: require('../../assets/manager/img_6.png'),

    };
  },
  methods: {

  },


};

</script>

<style scoped>

.layout-container-demo .el-header {
  position: relative;
  background-image: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);
  color: var(--el-text-color-primary);
}

.layout-container-demo .el-header {
  position: relative;
  background-image: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);
  color: var(--el-text-color-primary);
}

.layout-container-demo .el-aside {
  color: var(--el-text-color-primary);
  background: white;
  width: 20%;
  height: 100vh;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
.layout-container-demo .el-menu {
  border-right: none;
  height: 100vh;
  position: -webkit-sticky;
  position: sticky;
  top: 0;

}
.layout-container-demo .el-main {
  padding: 0;
  background-image: url("../../assets/manager/img_2.png");
  background-repeat:no-repeat ;
  background-size:100% 100%;
  background-attachment: fixed;
}
.layout-container-demo .toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  right: 20px;
  font-size:16px
}

.layout-container-demo .title {
  float: left;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;

}

.layout-container-demo .title {
  float: left;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.functions:hover{
  color: #ffd04b;
}




.el-card{
  margin-left: 5px;
  height: 400px;
}




</style>
