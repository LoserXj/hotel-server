<template>
  <div>
<!--  <header_a></header_a>-->
</div>

  <div id="body">
    <div id="app">
      <router-view/>
    </div>
  </div>
</template>

<script>

export default {
  name: 'App',

}
</script>

<style>
#app {
  height: 800px;
  background-image: url("@/assets/images/background.jpg");
  background-size: 100% 100%;
}
</style>
