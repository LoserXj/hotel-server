<template id="body">
  <!--  <div class="wrap">-->
  <!--    <form class="sign-in-form">-->
  <!--      <div class="form-title-wrap"><h2 class="form-title">酒店登录系统</h2></div>-->
  <!--      <label for="username"></label><input type="text" class="text" placeholder="用户名" id="username"/> <br/>-->
  <!--      <label for="password"></label><input type="password" class="text" placeholder="密码" id="password"/> <br/>-->
  <!--      <el-button type="primary" class="submit-btn" @click="onSubmit">登录</el-button> <br/>-->
  <!--      <el-button type="primary" @click="my_register" class="submit-btn">新用户注册</el-button>-->
  <!--    </form>-->
  <!--  </div>-->
  <div class="box1">
    <h1>Login</h1>
    <form>
      <div class="inputbox">
        <input type="text" required="" id="username" v-model="username">
        <label for="username">Username</label>
      </div>
      <div class="inputbox">
        <input type="password" required="" id="password" v-model="password">
        <label for="password">Password</label>
      </div>
      <input style="margin-left: 25px; margin-right: 80px" type="button" value="用户登录" @click="onSubmit">
      <input type="button" value="管理员登录" @click="onManagerSubmit">
      <br/>
      <input style="margin-left: 125px; margin-top: 20px" type="button" value="注册" @click="register">
    </form>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Login",

  data() {
    return {
      username: '',
      password: ''
    }
  },

  methods: {
    onManagerSubmit() {
      this.$http.get('http://localhost:8081/user/loginManager', {params:{tel: this.username, password: this.password}})
          .then(res => {
            if (res.data.code === 200)
              this.$router.push('/manager');
            else {
              this.$message.error(res.data.msg);
            }
          })
    },
    register() {
      alert("hahaha")
      this.$router.push('/register')
    },
    onSubmit() {
      this.$router.push('/manager')

      // //使用axios发送请求到后端
      // this.$http.get('http://localhost:8081/user/login', {params:{tel: this.username, password: this.password}})
      //     .then(res => {
      //       if (res.data.code === 200)
      //         //跳转为主页面
      //         this.$router.push('/manager');
      //       else {
      //         this.$message.error(res.data.msg);
      //       }
      //     })
    }
  },

}
</script>
<style scoped>
body{
  padding: 0px;
  margin: 0px;
}
.box1{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 400px;
  padding: 40px;
  background: rgb(0,0,0,0.8);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgb(0,0,0,0.5);
  border-radius: 10px;
}
.box1 h1{
  margin: 0 0 30px;
  padding: 0px;
  color: #ffffff;
  text-align: center;
}
.box1 .inputbox{
  position: relative;
}
.box1 .inputbox input{
  width: 100%;
  padding: 10px 0;
  margin-bottom: 30px;
  font-size: 18px;
  border: none;
  color: #ffffff;
  outline: none;
  background: transparent;
  border-bottom: 1px solid #ffffff;
}
.box1 .inputbox label{
  position:  absolute;
  top: 0;
  left: 0;
  font-size: 18px;
  color: #ffffff;
  pointer-events: none;
  transition: 0.5s;
}
.box1 .inputbox input:focus ~ label,
.box1 .inputbox input:valid ~ label{
  top: -18px;
  left: 0px;
  font-size: 16px;
  color: #03a9f4;
}
.box1 input[type="submit"]{
  background: transparent;
  border: none;
  outline: none;
  color: #ffffff;
  background: #03a9f4;
  padding: 10px 20px;
  cursor: pointer;
  border-radius: 5px;
}
</style>