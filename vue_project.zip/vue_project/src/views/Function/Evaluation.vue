<template>
  我是评价
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Evaluation"
}
</script>

<style scoped>

</style>